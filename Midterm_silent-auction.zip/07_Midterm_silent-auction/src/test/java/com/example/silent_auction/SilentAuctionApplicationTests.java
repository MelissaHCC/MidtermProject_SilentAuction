package com.example.silent_auction;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SilentAuctionApplicationTests {

	@Test
	void contextLoads() {
	}

}
