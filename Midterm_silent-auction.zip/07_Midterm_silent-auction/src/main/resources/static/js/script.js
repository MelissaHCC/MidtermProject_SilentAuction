// script.js

angular.module('module1', [])
  .controller('myController', function($scope) {
      // Initialize the welcome message
      $scope.welcomeMessage = " welcomes you to our Silent Auction!! We hope you find something to bid on. All proceeds are donated to ";

      // Optionally, you can add more logic here if needed
  });
