//SilentAuctionApplication.java

package com.example.silent_auction;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SilentAuctionApplication {

	public static void main(String[] args) {
		SpringApplication.run(SilentAuctionApplication.class, args);
	}

}
